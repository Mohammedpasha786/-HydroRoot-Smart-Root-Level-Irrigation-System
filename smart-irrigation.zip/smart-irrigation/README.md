# 🌿 HydroRoot — Smart Root-Level Irrigation System

A full-stack IoT solution for intelligent soil-moisture-based irrigation. Monitors moisture at the root level and automatically controls water pumps — saving water while keeping plants healthy.

---

## 📸 Features

| Feature | Description |
|---|---|
| 🌱 Root-Level Monitoring | Capacitive soil sensors near plant roots |
| 🤖 Auto Irrigation | Pump activates/stops based on moisture thresholds |
| 📊 Live Dashboard | Real-time React web app with charts & stats |
| 📡 IoT REST API | ESP8266 exposes JSON endpoints over WiFi |
| 💧 Water Usage Tracking | Logs litres used vs. schedule-based irrigation |
| 🔔 Alert System | Event log for pump state changes |

---

## 🗂 Project Structure

```
smart-irrigation/
├── src/
│   ├── App.jsx                  # Root React component
│   ├── main.jsx                 # Entry point
│   ├── styles.css               # Global styles
│   ├── components/
│   │   ├── Dashboard.jsx        # Overview tab
│   │   ├── PlantCard.jsx        # Single plant widget
│   │   ├── PlantGrid.jsx        # All-plants tab
│   │   ├── WaterUsageChart.jsx  # Analytics tab
│   │   └── AlertLog.jsx         # Alerts tab
│   ├── data/
│   │   └── plantData.js         # Seed data & history generator
│   └── utils/
│       └── irrigationLogic.js   # Threshold logic (shared with firmware)
├── arduino/
│   └── hydroroot_firmware.ino   # ESP8266 firmware
├── docs/
│   └── wiring_diagram.md        # Hardware wiring guide
├── index.html
├── package.json
├── vite.config.js
└── README.md
```

---

## 🚀 Quick Start — Web Dashboard

```bash
# 1. Install dependencies
npm install

# 2. Run development server
npm run dev
# → Open http://localhost:3000

# 3. Build for production
npm run build
```

---

## 🔌 Hardware Setup

### Components Required

| Component | Qty | Notes |
|---|---|---|
| ESP8266 (NodeMCU) | 1 | WiFi microcontroller |
| Capacitive Soil Moisture Sensor v1.2 | 1+ | One per plant station |
| DHT22 | 1 | Temperature + humidity |
| 5V Relay Module | 1 | Controls pump |
| Submersible Mini Pump (5V) | 1 | ~200mL/min flow |
| 18650 Battery + TP4056 | 1 | Or USB power supply |
| Jumper Wires, Tubing | — | — |

### Wiring

```
ESP8266          Moisture Sensor     Relay       DHT22
D1 (GPIO5)  ─────────────────────── IN
A0          ── AOUT
3.3V        ── VCC                              VCC
GND         ── GND               GND           GND
D2 (GPIO4)  ──────────────────────────────────  DATA
```

See [`docs/wiring_diagram.md`](docs/wiring_diagram.md) for full diagram.

---

## 🛠 Firmware Setup (Arduino IDE)

1. Install **ESP8266 board** in Arduino IDE  
   *Preferences → Additional Boards Manager URLs:*  
   `http://arduino.esp8266.com/stable/package_esp8266com_index.json`

2. Install libraries:
   - `ArduinoJson` by Benoit Blanchon
   - `DHT sensor library` by Adafruit
   - `ESP8266WiFi` (bundled with board package)

3. Edit `hydroroot_firmware.ino`:
   ```cpp
   const char* WIFI_SSID     = "YOUR_SSID";
   const char* WIFI_PASSWORD = "YOUR_PASSWORD";
   const char* PLANT_ID      = "P1";
   ```

4. **Calibrate** the sensor constants for your soil type:
   ```cpp
   #define SENSOR_DRY_RAW   820
   #define SENSOR_WET_RAW   380
   ```

5. Flash to NodeMCU (Board: `NodeMCU 1.0`, Upload Speed: `115200`)

---

## 📡 REST API (ESP8266)

Once flashed and connected, the device exposes:

| Endpoint | Method | Description |
|---|---|---|
| `GET /status` | GET | Full sensor JSON snapshot |
| `GET /pump?state=on` | GET | Turn pump on (disables auto) |
| `GET /pump?state=off` | GET | Turn pump off |
| `GET /auto?enabled=true` | GET | Enable auto irrigation |
| `GET /auto?enabled=false` | GET | Disable auto irrigation |

### Example Response — `/status`
```json
{
  "id": "P1",
  "name": "Tomato Bed A",
  "moisture": 27.3,
  "temperature": 29.8,
  "humidity": 61.2,
  "pump": true,
  "autoMode": true,
  "waterUsed": 0.42,
  "uptime": 3612
}
```

---

## 🌱 Irrigation Logic

```
moisture < 35%  →  Pump ON   (dry threshold)
moisture ≥ 65%  →  Pump OFF  (wet threshold)
```

The hysteresis gap (35–65%) prevents pump flutter. Thresholds are configurable per plant type.

---

## 📊 Example Dataset

| Plant ID | Moisture (%) | Temperature | Water Pump |
|---|---|---|---|
| P1 | 25 | 30°C | ON |
| P2 | 60 | 28°C | OFF |
| P3 | 20 | 32°C | ON |
| P4 | 70 | 27°C | OFF |

---

## 🤝 Contributing

1. Fork the repo  
2. Create your feature branch: `git checkout -b feature/multi-zone`  
3. Commit changes: `git commit -m "Add multi-zone scheduler"`  
4. Push: `git push origin feature/multi-zone`  
5. Open a Pull Request

---

## 📄 License

MIT License — free for personal and commercial use.
