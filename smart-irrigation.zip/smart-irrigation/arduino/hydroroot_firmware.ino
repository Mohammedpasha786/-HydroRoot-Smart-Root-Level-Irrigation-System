/*
 * HydroRoot — Smart Root-Level Irrigation System
 * Arduino/ESP8266 Firmware
 * 
 * Hardware:
 *   - Soil Moisture Sensor → A0
 *   - Water Pump Relay     → D1 (GPIO 5)
 *   - DHT22 Temp/Humidity  → D2 (GPIO 4)
 *   - Status LED           → D4 (built-in)
 *   - WiFi: ESP8266 built-in
 */

#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <ArduinoJson.h>
#include <DHT.h>
#include <EEPROM.h>

// ─── Configuration ──────────────────────────────────────────────
const char* WIFI_SSID     = "YOUR_SSID";
const char* WIFI_PASSWORD = "YOUR_PASSWORD";
const char* PLANT_ID      = "P1";
const char* PLANT_NAME    = "Tomato Bed A";

// Pin definitions
#define MOISTURE_PIN  A0
#define RELAY_PIN     5    // D1
#define DHT_PIN       4    // D2
#define LED_PIN       2    // D4 (active LOW on ESP8266)
#define DHT_TYPE      DHT22

// Thresholds
#define MOISTURE_DRY_THRESHOLD  35   // % — below this, pump activates
#define MOISTURE_WET_THRESHOLD  65   // % — above this, pump deactivates
#define READ_INTERVAL_MS        5000 // sensor read every 5s

// Calibration (adjust for your sensor)
#define SENSOR_DRY_RAW   820   // raw ADC when soil is completely dry
#define SENSOR_WET_RAW   380   // raw ADC when soil is saturated

// ─── Globals ─────────────────────────────────────────────────────
DHT dht(DHT_PIN, DHT_TYPE);
ESP8266WebServer server(80);

bool pumpOn       = false;
bool autoMode     = true;
float moisture    = 0.0;
float temperature = 0.0;
float humidity    = 0.0;
unsigned long lastRead = 0;
unsigned long pumpStartTime = 0;
float totalWaterLitres = 0.0;  // ~0.033 L/s for typical micro pump

// ─── Helpers ─────────────────────────────────────────────────────
float rawToMoisture(int raw) {
  raw = constrain(raw, SENSOR_WET_RAW, SENSOR_DRY_RAW);
  return map(raw, SENSOR_DRY_RAW, SENSOR_WET_RAW, 0, 100);
}

void setPump(bool state) {
  if (state == pumpOn) return;
  pumpOn = state;
  digitalWrite(RELAY_PIN, state ? LOW : HIGH);  // relay is active-LOW
  digitalWrite(LED_PIN,   state ? LOW : HIGH);
  if (state) {
    pumpStartTime = millis();
    Serial.println("[PUMP] ON");
  } else {
    float runSec = (millis() - pumpStartTime) / 1000.0;
    totalWaterLitres += runSec * 0.033;
    Serial.printf("[PUMP] OFF — ran %.1fs, total: %.2fL\n", runSec, totalWaterLitres);
  }
}

// ─── HTTP Handlers ───────────────────────────────────────────────
void handleStatus() {
  StaticJsonDocument<256> doc;
  doc["id"]          = PLANT_ID;
  doc["name"]        = PLANT_NAME;
  doc["moisture"]    = moisture;
  doc["temperature"] = temperature;
  doc["humidity"]    = humidity;
  doc["pump"]        = pumpOn;
  doc["autoMode"]    = autoMode;
  doc["waterUsed"]   = totalWaterLitres;
  doc["uptime"]      = millis() / 1000;

  String out;
  serializeJson(doc, out);
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.send(200, "application/json", out);
}

void handlePumpControl() {
  if (!server.hasArg("state")) {
    server.send(400, "application/json", "{\"error\":\"Missing 'state' param\"}");
    return;
  }
  autoMode = false;
  bool state = server.arg("state") == "on";
  setPump(state);
  server.send(200, "application/json", "{\"ok\":true,\"pump\":" + String(state ? "true" : "false") + "}");
}

void handleAutoMode() {
  if (!server.hasArg("enabled")) {
    server.send(400, "application/json", "{\"error\":\"Missing 'enabled' param\"}");
    return;
  }
  autoMode = server.arg("enabled") == "true";
  server.send(200, "application/json", "{\"ok\":true,\"autoMode\":" + String(autoMode ? "true" : "false") + "}");
}

void handleNotFound() {
  server.send(404, "application/json", "{\"error\":\"Not found\"}");
}

// ─── Setup ───────────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  Serial.println("\n[HydroRoot] Booting...");

  pinMode(RELAY_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(RELAY_PIN, HIGH);  // relay off (active LOW)
  digitalWrite(LED_PIN, HIGH);

  dht.begin();

  // Connect WiFi
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("[WiFi] Connecting");
  int tries = 0;
  while (WiFi.status() != WL_CONNECTED && tries < 30) {
    delay(500); Serial.print(".");
    tries++;
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.printf("\n[WiFi] Connected: %s\n", WiFi.localIP().toString().c_str());
  } else {
    Serial.println("\n[WiFi] Failed — running offline");
  }

  // Register routes
  server.on("/status",  HTTP_GET, handleStatus);
  server.on("/pump",    HTTP_GET, handlePumpControl);
  server.on("/auto",    HTTP_GET, handleAutoMode);
  server.onNotFound(handleNotFound);
  server.begin();
  Serial.println("[HTTP] Server started on port 80");
}

// ─── Loop ────────────────────────────────────────────────────────
void loop() {
  server.handleClient();

  if (millis() - lastRead >= READ_INTERVAL_MS) {
    lastRead = millis();

    int raw = analogRead(MOISTURE_PIN);
    moisture    = rawToMoisture(raw);
    temperature = dht.readTemperature();
    humidity    = dht.readHumidity();

    if (isnan(temperature)) temperature = 0;
    if (isnan(humidity))    humidity    = 0;

    Serial.printf("[SENSOR] M:%.1f%% T:%.1f°C H:%.1f%%\n",
                  moisture, temperature, humidity);

    // Auto irrigation logic
    if (autoMode) {
      if (!pumpOn && moisture < MOISTURE_DRY_THRESHOLD) {
        Serial.printf("[AUTO] Dry (%.1f%%) — activating pump\n", moisture);
        setPump(true);
      } else if (pumpOn && moisture >= MOISTURE_WET_THRESHOLD) {
        Serial.printf("[AUTO] Wet enough (%.1f%%) — stopping pump\n", moisture);
        setPump(false);
      }
    }
  }
}
