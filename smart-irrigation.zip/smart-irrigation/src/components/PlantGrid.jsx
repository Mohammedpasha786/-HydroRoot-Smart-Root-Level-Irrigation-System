import PlantCard from "./PlantCard";

export default function PlantGrid({ plants, togglePump, autoMode }) {
  return (
    <div className="page-section">
      <div className="section-title">
        <h2>All Plant Stations</h2>
        <span className="section-sub">{plants.length} sensors active</span>
      </div>
      <div className="plant-grid full">
        {plants.map(p => (
          <PlantCard key={p.id} plant={p} onToggle={() => togglePump(p.id)} autoMode={autoMode} />
        ))}
      </div>
    </div>
  );
}
